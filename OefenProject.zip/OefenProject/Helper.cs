﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OefenProject
{
    internal class Helper
    {
        private Game game;

        public Helper(Game game)
        {
        }

        public void AddFivePlayers()
        {
        }

        public void KillTwoPlayers()
        {
        }

        public void SetScoreToFive()
        {
        }

        public Game NewGame()
        {
            return new Game();
        }

        public void PauseGame()
        {
        }

        public void ResumeGame()
        {
        }

        public void EndGame()
        {
        }

        public void SetPlayerNameToNorbert()
        {
        }

        public void SetGameNumberToThree()
        {
        }

        public void SetLevelSummaryToReadyPlayerOne()
        {
        }
    }
}
