﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OefenProject
{
    /// <summary>
    /// The Test class
    /// </summary>
    internal class Test
    {
    }
}
