﻿using static System.Net.Mime.MediaTypeNames;

namespace OefenProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // BEGIN: NIETS AAN DEZE CODE VERANDEREN //
            // Als je code wilt toevoegen aan Main   //
            // doe dat dan hierboven.                //
            Test test = new Test();
            // EINDE: NIETS AAN DEZE CODE VERANDEREN //
        }
    }
}
